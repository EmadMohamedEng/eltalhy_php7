// cpanel - site_templates/countdown_tech/assets/config.js.tt Copyright(c) 2016 cPanel, Inc.
//                                                          All rights Reserved.
// copyright@cpanel.net                                        http://cpanel.net
// This code is subject to the cPanel license. Unauthorized copying is prohibited

window.cpanel = {
    data: {
        email: "",
        logo: "افتتاح الموقع الرسمي  للداعية الإسلامي السيّد أحمد الطلحي 20 ابريل 2017",
        social: [
            
            
            
            
            
            
        ]
    },
    style: {
        primary: "",
    },
    slides: [
        {
            type: 'countdown',
            backgroundImage: "",
            backgroundColor: "",
            color: "",
            buttonText: "Coming Soon",
            buttonLink: "",
            endTime: '2017-04-20T12:00:00.000Z'
        }
    ]
};
